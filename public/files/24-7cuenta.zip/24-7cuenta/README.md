# 247Account
Un código simple que ejecuta su cuenta de Discord 24/7

## Installation
NpmJS:
```
npm i dotenv express discord.js-selfbot-v13
```

## Configuración
Alternativamente, si desea alojarlo en su PC, simplemente agregue su token al archivo **.env****TOKEN** variable.

## Hosting
1. Crea una cuenta en Replit. https://replit.com.
2. Cree un proyecto en **NodeJS**, luego arrastre los archivos de **247Account** al proyecto.
3. Cree una variable de entorno llamada **TOKEN** en la configuración de Replit, luego coloque el token de su cuenta de Discord allí y ejecútelo.
4. Crea una cuenta en UptimeRobot. https://uptimerobot.com/
5. Agregue un nuevo **sitio** luego coloque la URL de producción del proyecto allí (Asegúrese de que haga pings cada 5 minutos) y luego guárdelo.
6. Estás listo para irte, solo deja el proyecto Replit solo y tu cuenta debe estar en línea incluso si tu PC está apagada.

## Usage
```
node index.js
```